import React, { useState } from "react";
//import Container from "../container/Container";
import {Container,  LogoutBtn} from '../index'
import Logo from "../Logo";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";


import { FaHome } from "react-icons/fa";
import { FaList } from "react-icons/fa6";
import { MdAddCircle, MdClose, MdLogin } from "react-icons/md";


function Header() {

  const authStatus = useSelector((state) => state.auth.status);

  const userRoll=useSelector((state) =>state.auth.userRoll);

  const isAdmin=( userRoll==="admin")
     console.log(isAdmin) 
  const navItems = [
    {
      name: "Home",
      icon: <FaHome />,
      slug: "/",
      active: true,
    },
    {
      name: "All blogs",
      icon: <FaList />,
      slug: "/all-posts",
      active: authStatus,
    },
    {
      name: "Add",
      icon: <MdAddCircle />,
      slug: "/add-post",
      active: authStatus,
    },
    {
      name: "Login",
      icon: <MdLogin />,
      slug: "/login",
      active: !authStatus,
    },
    {
      name: "Sign Up",
      slug: "/signup",
      active: !authStatus,
    },
  ];

  return (
    <header className="sticky top-0 left-0 w-full shadow-md z-50 bg-white">
      <Container>
        <div>
          <Link to="/">
           { <Logo />}
          </Link>
        </div>
        {isAdmin &&(<div>
           <nav className="  items-center min-h-[50px] max-w-[1200px] mx-auto">




          <ul className=" ml-auto gap-5 items-wright flex  ">
            {/*<ul className="hidden ml-auto gap-10 items-center md:flex">*/}
            {navItems.map((item) =>
              item.active ? (
                <li
                  key={item.name}
                  className="group text-slate-800 font-semibold-sm"
                >
                  {item.name !== "Sign Up" ? (
                    <Link
                      to={item.slug}
                      className="group flex items-center gap-1 duration-300 group-hover:text-[#29ca8e]"
                    >
                      {item.icon ? item.icon : null}
                      {item.name}
                    </Link>
                  ) : (
                    <Link
                      to={item.slug}
                      className="px-6 py-4 bg-[#29ca8e] text-white font-normal rounded-lg duration-300 group-hover:bg-[#156748]"
                    >
                      Sign Up
                    </Link>
                  )}
                </li>
              ) : null
            )}

            {authStatus && (
              <li>
                <LogoutBtn />
              </li>
            )}
          </ul>


        </nav>
        </div>) }
       

      </Container>
    </header>
  );
}

export default Header;
