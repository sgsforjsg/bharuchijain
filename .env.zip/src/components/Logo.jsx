import React from 'react'

function Logo({width = '100px'}) {
  return (
    <div>
<h1 className="font-bold text-black">
                <span className="text-[#29ca8e] text-xl md:text-2xl">
                    Jain'S
                </span>
                -Bharuch
            </h1>

    </div>
  )
}

export default Logo