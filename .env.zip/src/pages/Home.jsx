import React, { useEffect, useState } from 'react'
import appwriteService from "../appwrite/config";
import { Container, PostCard } from '../components'

import New from '../components/New';
import PostCardHome from '../components/PostCardHome';


function Home() {
    const [posts, setPosts] = useState([])

    useEffect(() => {

        const is_update=(localStorage.getItem('updated_at'))
        let items = JSON.parse(localStorage.getItem('l_items'));
        
        if (is_update!=Date.now()){
            localStorage.removeItem('l_items')  
            items=null         
        }
        if (items){
            console.log("time",Date.now())
            console.log("yes ")
            setPosts(items)
        }else{console.log("no")  
           appwriteService.getPosts().then((posts) => {
            console.log("appwrite", posts.documents)
            console.log("local storage", items)
            
            if (posts) {
                setPosts(posts.documents)
                localStorage.setItem('l_items', JSON.stringify(posts.documents));
                localStorage.setItem('updated_at',Date.now()+24*60*1000);
            }
        })
         }
        
    }, [])

    if (posts.length === 0) {
        return (
            <div className="w-full py-8 mt-4 text-center">
                <Container>
                    <div className="flex flex-wrap">
                        <div className="p-2 w-full">
                            <h1 className="text-2xl font-bold hover:text-gray-500">
                                Check Internet connection
                            </h1>
                        </div>
                    </div>
                </Container>
            </div>
        )
        
    }else{
        posts.sort((a,b)=>(a.title>b.title)?1:((b.title>a.title)?-1:0))
    }

    return (
        <div className='w-full py-8'>
            <Container>
               
           

                <div className='flex flex-wrap  '>
                { console.log('post',posts)}
                    {posts.map((post) => (
                      
                        <div key={post.$id} >
                            {/* <New {...post} />*/}
                           
                            <PostCardHome {...post} />
                        </div>
                    ))}
                </div>
            </Container>
        </div>
    )
}

export default Home