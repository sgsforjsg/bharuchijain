import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    status : false,
    userData: null,
    userRoll:"guests"
}

const authSlice = createSlice({
    name: "auth",
    initialState,
    reducers: {
        login: (state, action) => {
            state.status = true;
            state.userData = action.payload.userData;
            
           if( action.payload.userData.labels.includes("admin")){
           
            state.userRoll="admin"
           }
        },
        logout: (state) => {
            state.status = false;
            state.userData = null;
        }
     }
})

export const {login, logout} = authSlice.actions;

export default authSlice.reducer;