import conf from '../conf/conf.js';
import { Client, ID, Databases, Storage, Query } from "appwrite";

const client = new Client();

client
    .setEndpoint('https://cloud.appwrite.io/v1') // Your Appwrite Endpoint
    .setProject('662dd19e0038f4956649'); // Your project ID

const databases = new Databases(client);

export { databases };

