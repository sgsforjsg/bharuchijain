import React from 'react'

function Card1() {
  return (
    <body className="bg-gray-100 p-6">
    <div className="flex">
        <div className="bg-blue-500 flex-grow" style="flex-basis: 20%">Column 1</div>
        <div className="bg-green-500 flex-grow" style="flex-basis: 50%">Column 2</div>
        <div className="bg-red-500 flex-grow" style="flex-basis: 30%">Column 3</div>
    </div>
</body>
  )
}

export default Card1