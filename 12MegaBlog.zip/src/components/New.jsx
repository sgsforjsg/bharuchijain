import React from 'react'
import appwriteService from "../appwrite/config"
import { Link } from 'react-router-dom'
import { FaWhatsapp, FaRegAddressCard } from "react-icons/fa";
import { FaSquarePhone } from "react-icons/fa6";
import { useState } from "react"
import Adata from './Adata';

export default function New({ $id, title, bowner, bphone, featuredImage }) {
  const [open, setOpen] = useState(false)
  return (

    <div>
      <div>
        <table>
          <tbody className="table-auto">
            <tr>
              <td className="px-1 " >
                <a href={"https://api.whatsapp.com/send?phone=91" + bphone + "&text=Can%20I%20know%20more%20about%20your%20service.."} target='_blank' className="float">
                  <FaWhatsapp size={30} color='green' /> </a>

              </td>
              <td className="px-1 " >
                <a href={"tel:" + bphone}> <FaSquarePhone size={30} color='blue' /> </a>
              </td>
              <td className="px-1 "  ><Link to={`/post/${$id}`}>{title}</Link></td>
             { /*<td className="px-1 "  ><Link to={`/post/${$id}`}>{title}</Link></td>*/}

              <td >

                <button className="btn btn-success" onClick={() => setOpen(true)}>
                  <FaRegAddressCard size={30} />
                </button>
                <Adata open={open} onClose={() => setOpen(false)}>
                  <div className="text-center  w-56">

                    { /*<FaSquarePhone size={56} className="mx-auto text-green-500" />*/}
                    <div className="mx-auto my-4 w-48">

                      <p className="text-sm text-gray-500">{title} </p>
                    </div>
                    <div className="flex gap-4">
                      <button className="btn btn-success w-full">Continue n</button>
                      <button onClick={() => setOpen(false)} className="btn btn-light w-full">Cancel</button>

                    </div>
                  </div>

                </Adata>

              </td>



              {/*<h2
            className='text-xl font-bold'
  >{bowner}</h2>*/}
            </tr>
          </tbody></table>
      </div>


    </div>

  )
}


