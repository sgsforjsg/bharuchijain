import React from 'react'
import appwriteService from "../appwrite/config"
import { useEffect, useState } from 'react';
import { FaWhatsapp, FaRegAddressCard } from "react-icons/fa";
import { FaSquarePhone } from "react-icons/fa6";
import parse from "html-react-parser";

function PostCardHome({ $id, title, bowner, bphone, content,bdetails,baddress, featuredImage, genre }) {
    //console.log("titel", content)
    const [showModal, setShowModal] = useState(false);
    return (
        <div className='container w-screen  max-w-xs py-1 m-2 border-solid border-2 border-green-100 '>
            <div >
            < div className=' hover:shadow-lg outline-none focus:outline-none mr-1 mb-1'>
                <div className="flex flex-row  ">
                    <button className="w-1/7 " >
                        <a href={"https://api.whatsapp.com/send?phone=91" + bphone + "&text=Can%20I%20know%20more%20about%20your%20service.."} target='_blank' className="float">
                            <FaWhatsapp size={30} color='green' /> </a>
                    </button>

                    <button className="w-3/4 text-left"
                        type="button"
                        onClick={() => setShowModal(true)}
                    >
                        {title.toUpperCase()}
                    </button>
                    <button className="w-1/8 " > <a href={"tel:" + bphone}> <FaSquarePhone size={30} color='black' /> </a> </button>







                    {showModal ? (
                        <>
                            <div className="flex fixed top-0 justify-center items-center overflow-x-hidden overflow-y-auto fixed inset-0 p-4 z-50 outline-none focus:outline-none">
                                <div className="relative w-auto my-6 mx-auto max-w-3xl">
                                    <div className="border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none">
                                        <button
                                            className="text-red-500 background-transparent font-bold uppercase px-6 py-2 text-sm outline-none focus:outline-none mr-1 mb-1"
                                            type="button"
                                            onClick={() => setShowModal(false)}
                                        >
                                            Close
                                        </button>
                                        <div className="relative p-2 flex-auto">
                                            <div className='bg-gray-200'>{title.toUpperCase()}</div>
                                            {<div className='w-full justify-center mb-4 border-dashed border-2 border-indigo-600  '>
                                                <img src={appwriteService.getFilePreview(featuredImage)} alt={"Image of Jian Businessemen"}
                                                    className='object-scale-down   h-32 rounded-xl ' />

                                            </div>}
                                            <div className='bg-yellow-500'  >{bowner.toUpperCase()}</div>
                                            <div className='font-bold'>{bdetails.toUpperCase()}</div>
                                            <div className='italic'>{baddress.toUpperCase()}</div>

                                           {/* <div><div className="browser-css">
                                                {parse(content)}
                    </div></div>*/}
                                        </div>
                                        {<div className='w-full justify-center  '>
                                            <img src={appwriteService.getFilePreview(featuredImage)} alt={"Image of Jian Businessemen"}
                                                className='object-scale-down h-16 w-48 rounded-xl ' />

                                        </div>}
                                        <button
                                            className="text-red-500 background-transparent font-bold uppercase px-6 py-2 text-sm outline-none focus:outline-none mr-1 mb-1"
                                            type="button"
                                            onClick={() => setShowModal(false)}
                                        >
                                            Close
                                        </button>


                                        <div className="flex items-center justify-end p-1 border-t border-solid border-blueGray-200 rounded-b">

                                            {/*  <button
                                        className="text-white bg-yellow-500 active:bg-yellow-700 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1"
                                        type="button"
                                        onClick={() => setShowModal(false)}
                                    >
                                        Submit
            </button>*/}
                                        </div>
                                    </div>
                                </div>
                            </div>
                           
                        </>
                    ) : null}
                </div>
                <div className=' flex flex-wrep text-xs italic '>
                    <div className='text-left px-4 '>
                        {bowner.toUpperCase()}  
                    </div><div className='px-4'>
                        {genre.toUpperCase()}
                    </div>
                </div>
              
            </div>
            </div>
            </div>
    );
}

export default PostCardHome