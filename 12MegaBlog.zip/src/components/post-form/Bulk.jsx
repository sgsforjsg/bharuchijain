
import React, { useState } from 'react';
import { databases } from './appwrite';


function Bulk() {
  return (
    <div>Bulk</div>
  )
}

export default Bulk