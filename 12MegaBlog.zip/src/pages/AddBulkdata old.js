
import React, { useState } from 'react';
import appwriteService from "../appwrite/config1";
const AddBulkdata  = () => {
    const [file, setFile] = useState(null);

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const addDocumentsToAppwrite = async () => {
        if (!file) {
            console.error('No file selected');
            return;
        }

        const reader = new FileReader();
        reader.onload = async (e) => {
            try {
                const jsonData = JSON.parse(e.target.result);
                const databaseId = '66376eba000eb9cc6797'; // Replace with your Database ID
                const collectionId = '665d58190029330f0d99'; // Replace with your Collection ID
                
                jsonData.forEach(async (doc) => {
                    await databases.createDocument(databaseId, collectionId, 'unique()', doc);
                });

                console.log('Documents added successfully!');
            } catch (error) {
                console.error('Error adding documents: ', error);
            }
        };

        reader.readAsText(file);
    };

    return (
        <div>
            <input type="file" accept=".json" onChange={handleFileChange} />
            <button onClick={addDocumentsToAppwrite}>Add Documents</button>
        </div>
    );
};

export default AddBulkdata;
