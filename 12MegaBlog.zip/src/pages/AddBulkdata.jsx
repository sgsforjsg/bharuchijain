import { Client, Databases } from 'appwrite';
import React, { useState } from 'react';

const client = new Client();

client
    .setEndpoint('https://cloud.appwrite.io/v1') // Your Appwrite Endpoint
    .setProject('662dd19e0038f4956649'); // Your project ID

const databases = new Databases(client);

const AddBulkdata = () => {
  const [file, setFile] = useState(null);

  const handleFileChange = (e) => {
      setFile(e.target.files[0]);
  };

  const addDocumentsToAppwrite = async () => {
      if (!file) {
          console.error('No file selected');
          return;
      }

      const reader = new FileReader();
      reader.onload = async (e) => {
          try {
              const jsonData = JSON.parse(e.target.result);
              const databaseId = '66376eba000eb9cc6797'; // Replace with your Database ID
              const collectionId = '663773e1002a4fe7be40'; // Replace with your Collection ID

              jsonData.forEach(async (doc) => {
                  await databases.createDocument(databaseId, collectionId, 'unique()', doc);
              
              console.log(doc)
                });

              console.log('Documents added successfully!');
          } catch (error) {
              console.error('Error adding documents: ', error);
          }
      };

      reader.readAsText(file);
  };

  return (
      <div>
          <input type="file" accept=".json" onChange={handleFileChange} />
          <button onClick={addDocumentsToAppwrite}>Add Documents</button>
      </div>
  );
};

export default AddBulkdata;
