import React, { useEffect, useState } from 'react'
import appwriteService from "../appwrite/config";
import { Container, PostCard } from '../components'

import New from '../components/New';
import PostCardHome from '../components/PostCardHome';


function Home() {
    const [posts, setPosts] = useState([])
    const [searchValue, setSearchValue] = useState('');
    useEffect(() => {

        const is_update=(localStorage.getItem('updated_at'))
        let items = JSON.parse(localStorage.getItem('l_items'));
        
        if (is_update<Date.now()){
            localStorage.removeItem('l_items')  
            items=null     
                console.log('removed data from local storage')
        }
        if (items){
            console.log("time",Date.now())
            console.log("yes ")
            setPosts(items)
        }else{console.log("no")  
           appwriteService.getPosts().then((posts) => {
            console.log("appwrite", posts.documents)
            console.log("local storage", items)
            
            if (posts) {
                setPosts(posts.documents)
                localStorage.setItem('l_items', JSON.stringify(posts.documents));
                localStorage.setItem('updated_at',Date.now()+24*60*1000);
            }
        })
         }
        
    }, [])

    if (posts.length === 0) {
        return (
            <div className="w-full py-8 mt-4 text-center">
                <Container>
                    <div className="flex flex-wrap">
                        <div className="p-2 w-full">
                            <h1 className="text-2xl font-bold hover:text-gray-500">
                                Check Internet connection
                            </h1>
                        </div>
                    </div>
                </Container>
            </div>
        )
        
    }else{
        posts.sort((a,b)=>(a.title>b.title)?1:((b.title>a.title)?-1:0))
    }

    const handleInputChange = (event) => {
        setSearchValue(event.target.value);
      };

      const filteredData = posts.filter(
        (item) =>
          item.title.toLowerCase().includes(searchValue.toLowerCase()) ||
          item.bowner.toLowerCase().includes(searchValue.toLowerCase())||
          item.genre.toLowerCase().includes(searchValue.toLowerCase())  
         
      );


     


    return (
        <div className='w-full py-3'>
            <Container>
               
            
      <div className="w-full left-0 max-w-xs">        
        <input
          type="text"
          id="inputField"
          value={searchValue}
          onChange={handleInputChange}
          className="shadow appearance-none border rounded w-1/2 text-left  py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          placeholder="Type here to search"
        />
      </div>
  





     

                <div className='flex flex-wrap   '>
                { console.log('post',posts)}
                    {filteredData.map((post) => (
                      
                        <div key={post.$id} >
                            {/* <New {...post} />*/}
                           
                            <PostCardHome {...post} />
                        </div>
                    ))}
                </div>
            </Container>
        </div>
    )
}

export default Home